import React from 'react'
import '../../App.css'

const Services = () => {
    return (
        <h1 className='services'>Services</h1>
    )
}

export default Services;