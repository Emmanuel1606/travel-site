import React from 'react'
import '../../App.css'

const SignUp = () => {
    return (
        <h1 className='sign-up'>Sign Up</h1>
    )
}

export default SignUp;